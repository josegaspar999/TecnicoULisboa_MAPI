
MAPI Introductory Laboratory (lab00)
------------------------------------

This folder contains the empty project "empty.stu"
	to be opened with Schneider's Unity Pro

In Matlab, use the following to open Webpages and lab guides:
	mapi_www
