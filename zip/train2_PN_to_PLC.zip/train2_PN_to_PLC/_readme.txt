
Example of making a PLC program from a Petri net

2015, 2020 (timed transitions), 2021 (IO++) JG

------------------------------------------------


1. First function to run:

>> tst3_blink_on_off

The output is written to
	tst3_mk_program_res.txt

Requires compiler functions (are avaiable after login_mapi.m)
	pn_to_plc_compiler/*.m

The Petri net is loaded in tst3_blink_on_off.m with:
	define_petri_net()

Mapping of the Petri net to physical inputs and outputs is done in:
	define_input_mapping(), define_output_mapping()


2. To do in Unity:

- Create one new project, including the declaration of the hardware

- Create one ST section under MAST, and paste there the code

- Declare in "Variables & FB instances -> Elementary Variables"
timer_output_flag	BOOL
my_time_i		TIME (i indicates 1, 2, ...)

- Declare in "Variables & FB instances -> Elementary FB Instances"
MY_TON_i		Function block TON

** in case steps 1 or 2 fail, you can download a UnityPro project with Matlab:
get_files blink_on_off_and_pause


3. Run the PLC program

- Run the PLC program using the UnityPro simulator

- Check memories %m10..%m13

- (Facultative) Run "myterminal5" in Matlab and click refresh
