
Five philosophers Dinner

Nov2013 JG

------------------------

Note: This demo requires RDP.M found in the tpn5 toolbox.
Please install the toolbox and then run file_put_in_path.m

To see the asked to dinner time signals:
>> pdinner_IO

To run the main demo:
>> pdinner_tst
