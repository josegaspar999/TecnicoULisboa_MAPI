function qk= PN_tfire(act, t)
% Possible-to-fire transitions given PN outputs (act) and the time t
%
% act: 1xN : actuation signals
% t  : 1x1 : time
% qk : 1xM : possible firing vector (to be filtered later with enabled
%            transitions)

alpha1=0.06; alpha2=0.45; beta=0.92; gamma=0.84;
a= rand(1); b= rand(1); c= rand(1);
q1= (a<alpha1);
q2= (alpha1<=a & a<alpha1+alpha2);
q3= (alpha1+alpha2 <= a);
qk= [q1 q2 q3 (b<beta) (beta<=b) (c<gamma) (gamma<=c)]';
