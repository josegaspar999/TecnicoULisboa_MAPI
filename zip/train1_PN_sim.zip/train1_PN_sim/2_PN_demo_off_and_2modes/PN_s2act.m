function act= PN_s2act(MP)
% Actuation of the Petri net
act= [];
