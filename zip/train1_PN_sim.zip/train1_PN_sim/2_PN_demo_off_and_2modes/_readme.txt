
SPN: OFF + 2 modes
This folder has a simulation demo (confirms steady state values)

Jun 2022 J. Gaspar

------------------------

To run the demo:
>> off_and_2modes_tst
