function off_and_2modes_tst(tstId)
if nargin<1
    tstId= 2;
end
% warning('off','MATLAB:dispatcher:InexactCaseMatch');
% file_put_in_path('rdp.m');

switch tstId

    case 2, % test the Petri net

        % run the simulation
        % 1. define the PN matrices Pre, Post and vector M0
        % 2. sim results in a structure: ret.t, ret.qin, ret.M, ret.yout
        [Pre, Post, M0] = PN_define;
        ret= PN_sim( Pre, Post, M0, [0 100 .01] );
        stateFreqEst= cnorm_by_count( cumsum( ret.M, 1) );

        % plot the results
        figure(201), clf;
        subplot(2,1,1); plot_z(ret.t, ret.M, '-');
        xlabel('time'); ylabel('place number'); grid on;
        title('State of the PN along time')
        subplot(2,1,2);
        %plot(ret.t, stateFreqEst )
        plot(stateFreqEst )
        title( sprintf('usage = %.2f %.2f %.2f', stateFreqEst(end,:)) )
        grid minor

    otherwise
        error('invalid tstId')
end

return


function [Dm, Dp, M0] = PN_define
D= [
    NaN -1 -1   0 +1   0 +1
    0   +1  0 NaN -1   0  0
    0    0 +1   0  0 NaN -1
    ];
Dm= -D.*(D<0); Dm(isnan(Dm))= 1;
Dp=  D.*(D>0); Dp(isnan(Dp))= 1;
M0= [1 0 0]';
return


function y= cnorm_by_count( x )
% normalize column by counting
n= (1:size(x,1))';
n= repmat( n, 1, size(x,2) );
y= x./n;
