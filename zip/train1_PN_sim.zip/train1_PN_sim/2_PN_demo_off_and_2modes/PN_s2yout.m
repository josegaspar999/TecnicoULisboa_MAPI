function yout= PN_s2yout(MP)
% General output of the Petri net
% see Petri Net in *.rdp
%
% MP: 1xN : marked places (integer values >= 0)
% yout: 1xM : outputs given the current state MP

yout= MP;
yout= yout(:)';
