function two_machines_tst( tstId )
%
% Simulate the Petri net in the paper
% [Zurawski�94] "Petri nets and industrial applications: A tutorial."
% R. Zurawski, M. Zhou. IEEE Trans. on Industrial Electronics 41.6 (1994): 567-583.
% https://www.researchgate.net/publication/3217035

% See also MAPI slides

% Jun2023 JG

if nargin<1
    tstId= 2; %1;
end

switch tstId
    case 1, run_pipe2;  % two_machines_tst(1)
    case 2, run_PN;     % two_machines_tst(2)
end


function run_pipe2
msg= {
    'Going to open PN editor PIPE2'
    'See file "two_machines.xml" in the current folder:'
    pwd
    };
h= msgbox(msg); uiwait(h);
pn_editor


function run_PN
[Dm, Dp, M0]= rdp_pipe2('two_machines.xml');

PN= struct('Dp',Dp, 'Dm',Dm, 'M0',M0, ...
    'ti_tf', [0 100], ...
    'PN_tfire',@PN_tfire, 'PN_s2act',@PN_s2act, 'PN_s2yout',@PN_s2yout);

ret= PN_sim2(PN);

stateFreqEst= cnorm_by_count( cumsum( ret.M(:,1:4), 1) );

figure(201); clf
subplot(1,3,1:2); imshow('two_machines_intro.png');
subplot(1,3,3); plot( ret.t, stateFreqEst, '.-' )
title('Average #tokens vs time [sec]');
legend_from_values( stateFreqEst(end,:), 'freq%d(tf)= %.2f' );

return


function qk= PN_tfire(act, t)
% Possible-to-fire transitions
% act: 1xN : PN outputs (PLC outputs) 
% t  : 1x1 : time
% qk : 1xM : possible firing vector

x= [0.982591 
    0.122824 
    0.098259 
    0.089308 
    0.714460 ];

qk= round( rand(5,1) < x );


function yout= PN_s2yout(MP)
yout= MP;


function act= PN_s2act(MP)
act= [];


function y= cnorm_by_count( x )
% normalize column by counting
n= (1:size(x,1))';
n= repmat( n, 1, size(x,2) );
y= x./n;


function legend_from_values( values, cstr )
% legend_from_values( stateFreqEst(end,:), 'freq%d(tf)=%f' );
leg= {};
for i= 1:length(values)
    leg{i}= sprintf( cstr, i, values(i) );
end
legend(leg)
