
Using a freeware Petri net editor and simulator PIPE2:
https://pipe2.sourceforge.net/

2023 JG

------------------------------------------------

** Is assumed you did install Java in your PC **
** Is assumed you are in a MAPI course, and did login in Matlab**

-- Install the Petri Net editor PIPE2 within Matlab:
cd2file('_MAPI_readme.txt')
data_download

-- Start the PIPE2 editor within Matlab:
pn_editor


-- To run a Matlab demo:
two_machines_tst
