
MAPI Introductory Laboratory
----------------------------

This folder contains the a project with timers

See in this folder links to
(i) enter the course webpage "MAPI_webpage" and
(ii) get the videoconference link "MAPI_webpage_videoconf".
