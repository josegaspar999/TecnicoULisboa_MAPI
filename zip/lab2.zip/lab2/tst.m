function tst( tstId )
%
% Use this file to automate some of your tasks within Matlab
% If unsure what to do, press F5 and click MAPI Main webpage

% May2023, JG

if nargin<1
    tstId= 0;
end

switch tstId
    case 0
        % open MAPI webpage or Lab guides in PDF
        mapi_www

    case 101, get_files logger; % tst(101)
    case 102, get_files timers; % tst(102)
    case 103, get_files mix_io_and_show_strings; % tst(103)
        % cases >= 101 mean download PLC code samples to the current folder

    case 200
        % launch myterminal5 a GUI to interact with the PLC
        myterminal5

    otherwise
        error('inv tstId');
end


