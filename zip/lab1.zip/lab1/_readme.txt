
MAPI Laboratory
---------------

You can use this folder both in the real laboratory 
and in your home. This folder is yours,
i.e. your writing here does not affect your colleagues.


Get a timers example using Matlab:
>> get_files timers
