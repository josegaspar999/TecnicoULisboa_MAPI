
Folder for groups to develop their projects with Git repositories
-----------------------------------------------------------------

	** This folder is supposed to be kept private by each group **

Place here the work you are doing with your colleagues of the group. I recommend using a Github
account, or similar, so that the folders and files are synchronized among all the elements of 
the group.

-- Run a demo, assuming you installed TortoiseGIT and 
installed the separate command line tools GIT:
(1, do once) in Matlab run  >> mygit('test'); !start .
(2, do once) see if the just created batch file runs without errors
(3) in Matlab run >> mygit('clone')

-- Your own usage requires creating Git repository(ies).
The links in this folder are HELP instructions to
(1) create a new Github account
(2) create a new Github repository
(3) invite collaborators

-- As soon as you have Git repositories:
(1) In Matlab >> edit mygit_info
(2) Delete the info about "work00" if you want, and create your own cases
(3) Create URL tests with >> mygit('test')
(4) Get a copy of your group files with >> mygit('clone')
(5) When needed, update your copy of files with >> mygit('pull')

-- Whenever you want to save your own work do in Matlab:
>> mygit('push')
or do a right-mouse-click one the your git folder and select "Git sync" and then "Push"
