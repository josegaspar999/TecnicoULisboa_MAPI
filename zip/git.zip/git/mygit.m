function mygit( cmd )
%
% Help each group have GIT repositories and collaborate at home
% 
% Typical usages:
% mygit('test') % always do this before cloning
% mygit('clone')
% mygit('pull')
% mygit('push')
% 
% To see the implementation of "mygit.m"  >> type mygit

% 1.4.2020 JG

if nargin<1
    cmd= 'pull';
end

% call code available in another folder
mygitx(cmd)
