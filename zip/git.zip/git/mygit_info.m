function ret= mygit_info
% You are expected to write the correct information in this file
% 1.4.2020 JG

% a demo (public) repository to get into ".\work00"
% you are expected to add your private (own) repositories
ret= {
    struct('dname', 'work00', ...
    'url', 'https://github.com/josegaspar999/UnityPro_experiments.git');
    };

% to have multiple Git reposisitories just write multiple structs
% ret= {
%     struct('dname', 'work01', 'url', 'https://aaaaaaaaaaa'); ...
%     struct('dname', 'work02', 'url', 'https://bbbbbbbbbbb'); ...
%     };
