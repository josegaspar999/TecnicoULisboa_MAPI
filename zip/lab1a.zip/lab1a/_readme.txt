
API Laboratory
--------------

You can use this folder both in the real laboratory 
and in your home. This folder is yours,
i.e. your writing here does not affect your colleagues.

See the guide in section "Lab" by clicking the shortcut in this folder:
MAPI_webpage
