function act= PN_s2act(MP)
% Actuation of the Petri net
% see Petri Net in *.rdp
%
% p1,p2,p3: red1,green1,orange1
% p4,p5,p6: red2,green2,orange2
% p7: mutual exclusion

act= [];
